#!/bin/bash
find . -type f -name "*.png" | while read file; do
  if ! pngcheck "$file"; then
    rm "$file"
    echo "Deleted $file due to corruption."
  fi
done
