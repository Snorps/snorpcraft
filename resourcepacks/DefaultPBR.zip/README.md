# Default PBR

For more information visit https://modrinth.com/resourcepack/defaultpbr

Based on https://github.com/Poudingue/Vanilla-Normals-Renewed